//###########################################################################
//
// FILE:   epwm_ex11_configure_signal.c
//
// TITLE:  Configure desired EPWM frequency & duty
//
//! \addtogroup driver_example_list
//! <h1> EPWM Configure Signal </h1>
//!
//! This example configures ePWM1, ePWM2, ePWM3 to produce signal of desired
//! frequency and duty. It also configures phase between the configured
//! modules.
//!
//! Signal of 10kHz with duty of 0.5 is configured on ePWMxA & ePWMxB
//! with ePWMxB inverted. Also, phase of 120 degree is configured between
//! ePWM1 to ePWM3 signals.
//!
//! During the test, monitor ePWM1, ePWM2, and/or ePWM3 outputs
//! on an oscilloscope.
//!
//! - ePWM1A is on GPIO0
//! - ePWM1B is on GPIO1
//! - ePWM2A is on GPIO2
//! - ePWM2B is on GPIO3
//! - ePWM3A is on GPIO4
//! - ePWM3B is on GPIO5
//!
//
//###########################################################################
//
//
// $Copyright:
// Copyright (C) 2022 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

//
// Included Files
//
#include <sci_pwm.h>
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "pwm.h"
#include "sci_pwm.h"
#include "cla_custom.h"
#include "adc_soc.h"
#include <string.h>
#include<stdio.h>
#include <stdlib.h>

//
// Globals
//


uint16_t adc_val[8];


uint16_t loopCounter = 0;
enum menu{Start = 49, Phase = 50, Reset = 51, Turnoff = 52, Help = 53, Ready = 54};
//
// Main
//
void main(void)
{
    unsigned char *receivedDegree;
    uint16_t receivedChar;
    unsigned char *msg;
    uint16_t rxStatus = 0U;


    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Disable sync(Freeze clock to PWM as well)
    //
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    //
    // Init GPIO pins for ePWM4, ePWM5, ePWM6,
    //
    //Board_init();
    pwm_setup();
    sci_setup();

    //
    // Enable global Interrupts and higher priority real-time debug events:
    //
    EINT;  // Enable Global interrupt INTM
    ERTM;  // Enable Global realtime interrupt DBGM

    //
    // Send starting message.
    //
    bool flag = false;
    msg = "\r\n\n\nHello World!\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 17);
    msg = "\r\nMenu:\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 8);
    msg = "\r\n1.Start PWM\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 15);
    msg = "\r\n2.PWM Phase Control\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 22);
    msg = "\r\n3.Reset\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 10);
    msg = "\r\n4.Turn off\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 13);
    msg = "\r\n5.Help\0";
    SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 9);
    for(;;)
    {

        // Menu choice
        msg = "\r\nPlease Make your choice:\n\0";
        SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 28);
        receivedChar = SCI_readCharBlockingFIFO(SCIA_BASE);
        rxStatus = SCI_getRxStatus(SCIA_BASE);
        if((rxStatus & SCI_RXSTATUS_ERROR) != 0)
        {
            //
            //If Execution stops here there is some error
            //Analyze SCI_getRxStatus() API return value
            //
            ESTOP0;
        }


            switch(receivedChar){
            case Start:
                msg = "\r\nPWM is turned on\n\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 23);
                SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
                break;
            case Phase:
                // House keeping
                msg = "\r\nFormat: 45-045, 180-180 \0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 25);

                // Receive input
                msg = "\r\nEnter a degree(0-180): \0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 27);
                SCI_readCharArray(SCIA_BASE, (uint16_t*)receivedDegree, 3);
                rxStatus = SCI_getRxStatus(SCIA_BASE);
                if((rxStatus & SCI_RXSTATUS_ERROR) != 0)
                {
                    //
                    //If Execution stops here there is some error
                    //Analyze SCI_getRxStatus() API return value
                    //
                    ESTOP0;
                }

                // Calculate the phase
                char degree[3];
                int i = 0;
                int phase;
                for(i ; i < 3; i++){
                    degree[i] = (uint16_t)receivedDegree[i];
                }
                phase = atoi(degree);

                // Tell user what they sent
                msg = "\r\nPWM Phase: \0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 14);
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)receivedDegree, 3);

                // Configure phase shift for EPWM6
                if (phase >= 0 && phase  <= 180){
                    configurePhase(myEPWM6_BASE, myEPWM5_BASE, (uint16_t)phase);
                    EPWM_enablePhaseShiftLoad(myEPWM6_BASE);
                    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
                }
                break;
            case Reset:
                //
                // Reset phase shift for EPWM6
                //
                msg = "\r\nReset PWM6 to 90 phase shift\n\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 35);
                configurePhase(myEPWM6_BASE, myEPWM5_BASE, 90);
                EPWM_enablePhaseShiftLoad(myEPWM6_BASE);
                break;
            case Turnoff:
                //
                //Turn off PWM
                //
                msg = "\r\nPWM is turned off\n\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 24);
                SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
                break;
            case Help:
                msg = "\r\nMenu:\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 8);
                msg = "\r\n1.Start PWM\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 15);
                msg = "\r\n2.PWM Phase Control\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 22);
                msg = "\r\n3.Reset\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 10);
                msg = "\r\n4.Turn off\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 13);
                msg = "\r\n5.Help\n\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 10);
                break;
//            case Ready:
//                msg = "\r\nReady to Start\n\0";
//                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 18);
//                break;
            default:

                msg = "\r\nInput Incorrect\0";
                SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 21);
                break;

            }

            //
            // Increment the loop count variable.
            //
            loopCounter++;
            }

}


