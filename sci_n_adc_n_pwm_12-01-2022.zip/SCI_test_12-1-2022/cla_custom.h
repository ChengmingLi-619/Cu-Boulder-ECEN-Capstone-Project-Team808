/*
 * cla_custom.h
 *
 *  Created on: Dec 1, 2022
 *      Author: LiChe
 */

#ifndef CLA_CUSTOM_H_
#define CLA_CUSTOM_H_

#include "driverlib.h"
#include "device.h"


void initCLA(void);


#endif /* CLA_CUSTOM_H_ */
