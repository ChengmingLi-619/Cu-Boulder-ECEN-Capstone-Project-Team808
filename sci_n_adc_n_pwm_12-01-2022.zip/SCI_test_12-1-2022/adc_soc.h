/*
 * adc_soc.h
 *
 *  Created on: Dec 1, 2022
 *      Author: LiChe
 */

#ifndef ADC_SOC_H_
#define ADC_SOC_H_

#include "driverlib.h"
#include "device.h"
void initADC(void);
void initADCSOC(void);


#endif /* ADC_SOC_H_ */
